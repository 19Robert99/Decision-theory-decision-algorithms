package paint;

public interface Class1D extends Paint{
	
}